"""
Implement a function called sort_students that takes a list of students objects as input and sorts the 
list based on their CGPA (cumulative grade point average) in descending order. Each students object
has the following attriibutes: name (string), roll_number (string), and cgpa (float). test the function
with different input lists of students.
"""

class students:

  def __init__(self, name, roll_number, cgpa):
    self.name = name
    self.roll_number = roll_number
    self.cgpa = cgpa


def sort_students(students_list):
  # sort the list of students i desceding order of cgpa
  sorted_students = sorted(student_list,
                           key=lambda student: student.cgpa
                           reverse=True)
  # sntax _ lambda arg:exp
  return sorted_students


# example usage:
students = [
     students("Hari","A123",7.8),
     students("Srikanth","A124",8.9),
     students("Saumya","A125",9.1),
     students("Mahidhar","A126",9.9),
]

sorted_students = sort_students(students)

# print the sorted list of students
for student in sortde_studentts:
  print("Name: {}, Roll number: {}, CGPA: {}".format(student.name
  student.roll_number,

                                                     students.cgpa))
  

  
  

  
  