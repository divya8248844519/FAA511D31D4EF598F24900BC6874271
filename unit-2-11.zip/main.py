   implement a class called bankaccount that represents a bank account. The class should have private .
atteibyte for acount number, account holder name, and account balance include methods to 
desposit money, withdraw money, and display the account balance. Ensure that the account balance 
cannot be accessed directly from outside the class. write a program to create an instance of the 
Bankaccount class and test the deposit and withdrawl functionality.'''


class BankAccount:

  def__init__(self, account number, account_holder_name
  initial_balance=0.0):
  self.__account_number = account_number
  self.__account_holder_name = account_holder_name
  self.__account_balance = initinal_balance
  def deposit(self, amount):
    if amount > 0:
      self.__account_balance += amount
      print("deposited {}. new balance: {}".format(amount,self.__account_balance))

self.__account_balance))
   else:
    print("invalid desposit amount".) 

  def withdrw(self, amount):
    if amount > 0 and amount <= self.__account_balance:
      self._account_balance_=amount
      # self >.__account_balane= self._account.balance = amount
      print("withdrew {}. new blance: {}".format(amount,self._account_balance))
self._acc0unt_balance))
else:
    print("Invalid withdrawal amount or insufficient balance.")
    
  def display_balance(self):
    print("Account balance for {} (Account #{}: {}."format(
        self._account_number,
              self._account_balance))
              

# create an inatance of the bankaccount class
account = BankAccount(account_number="123456789",
                      account_holder_name="Hari Prabu",
                      intial_balance=5000.0)

# test deposit and withdrawal unctionaltty
account.display_balance()
account.desposit(500.0)
account.withdraw(200)
account.withdraw(20000.0)
account.display_balance()

  